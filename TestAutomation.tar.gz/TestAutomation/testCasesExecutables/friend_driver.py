# driver for add_friend in friends.py

from dbus.mainloop.glib import DBusGMainLoop
from friends import *

# don't know why, but this line makes things work
# it also minimizes all my windows whenever i run the driver
mainloop = DBusGMainLoop(set_as_default=True)

# FriendBuddyModel instances
friend1 = FriendBuddyModel('One', 'keyOne', 'accountOne', 'idOne')

return friend1

